<?php

namespace mifftah;

use Illuminate\Database\Eloquent\Model;

class Wishlist extends Model
{
    //
}
