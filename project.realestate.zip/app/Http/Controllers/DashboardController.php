<?php
namespace mifftah\Http\Controllers;

//use App\About;
use Illuminate\Http\Request;

//use App\User;
//use App\Songs;
//use App\Shows;
//use App\Albums;
//use App\Socials;
//use App\Blogs;
use Illuminate\Support\Facades\Auth as aauth;
use \Faker as Faker;
use \Carbon as Carbon;
use mifftah\User;
use mifftah\Listings;

class DashboardController extends Controller {
	
	function __construct() {
		$this->middleware('auth');
	}
	
	public function index() {
		return view('dashboard.index');
	}
	
	public function getall() {
		$users = User::orderBy('id', 'desc')->paginate(10);
		return view('dashboard.userList', compact('users'));
	}
	
	public function adduser(Request $request) {
		$this->validate($request, ['']);
		return view('dashboard.userAdd', compact('user'));
	}
	
	public function getsingle($id) {
		$user = User::where('id', $id)->first();
		return view('dashboard.userEdit', compact('user'));
	}
	
	public function updateUserRecord() {
		$user = User::findOrFail(aauth::user()->id);
		return view('dashboard.adminEdit', compact('user'));
	}
	
	
	public function updateUser(Request $request, $id) {
		$this->validate($request, [
			'email' => 'required|unique:users|max:255',
		]);
		$userexists = User::findOrfail($id);
		$userexists->update($request->all());
		return redirect('admin/getall');
	}
	
	public function delu($id) {
		$user = User::destroy($id);
		if ($user == 1) {
			return redirect('/getall');
		} else {
			return "Soory Wrong Argument Passed Go back and dont try to do fancy things things are tight here";
		}
	}
	
	/*============================*/
	/* manage agents  */
	/*============================*/
	public function getallagents() {
		$users = User::whereType(1)->orderBy('id', 'desc')->paginate(10);
		return view('dashboard.userList', compact('users'));
	}
	
	/* ================================================================================= */
	/* withdraws section */
	/* ================================================================================= */
	
	public function getuserdata($id) {
		return User::whereId($id)->get();
	}
	
	/* ================================================================================= */
	/* Shows */
	/* ================================================================================= */
	
	
	public function manageLeads() {
		$data = Listings::whereAvailability(1)->orderBy('id', 'desc')->paginate(10);
		return view('dashboard.leadsList', compact('data'));
	}
	
	public function addLeads() {
		return view('dashboard.leadsAdd', compact('data'));
	}
	
	public function editlead($id) {
		$data = Listings::findOrFail($id);
		return view('dashboard.leadsEdit', compact('data'));
	}
	
	
	public function delead($id) {
		$dellead = Listings::destroy($id);
		if ($dellead == 1) {
			return redirect(url('/admin/manageLeads'));
		} else {
			return "Soory Wrong Argument Passed Go back and dont try to do fancy things things are tight here";
		}
	}
	
	
}
