 
<div id="slides" class='mainslider'>
 <div class='slides-container'>
  <div class='sangar-content'><img src='userdata/Public/SlideImages/slide-1.jpg'> </div>
  <div class='sangar-content'><img src='userdata/Public/SlideImages/slide-2.jpg'> </div>
  <div class='sangar-content'><img src='userdata/Public/SlideImages/slide-3.jpg'> </div>
  <div class='sangar-content'><img src='userdata/Public/SlideImages/LoganStandout1.jpg'> </div>
 </div>
 <nav class="slides-navigation">
  <a href="#" class="next slidernav"></a>
  <a href="#" class="prev slidernav"></a>
 </nav>
</div>
<!-- Slider ends -->

  <div class="overlayb"></div>