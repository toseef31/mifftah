<div class="slideingmenu dblue_bg">
  <div class="slideingmenu_in">
    <div class="closesilde"> Close<i class="flaticon-cross97 right"></i></div>
    <ul class="slideingmenu_ul">
      <li class="slidingmenuli"><a class="slidemneu_a" href="{{ url('/') }}">Search Homes</a></li>
      <li class="slidingmenuli"><a class="slidemneu_a" href="{{ url('/agents') }}">Agent Finder</a></li>
      <li class="slidingmenuli"><a class="slidemneu_a" href="{{ url('mortgage') }}">Mortgage Calculator</a></li>
      <li class="slidingmenuli"><a class="slidemneu_a" href="{{ url('/affordability') }}">Affordability Calculator</a></li>
      <li class="slidingmenuli"><a class="slidemneu_a" href="{{ url('/rentorbuy') }}">Rent Vs Buy</a></li>
      <li class="slidingmenuli"><a class="slidemneu_a" href="{{ url('/howitwork') }}">How to Sell on For Sale Network</a></li>
      <li class="slidingmenuli"><a class="slidemneu_a" href="{{ url('/support') }}">Support Desk</a></li>
    </ul>
    
    <div class="responsivemenu fulwidthm left">
      <ul class="re_ul left fulwidthm left">
      </ul>
    </div>
  </div>
</div>