<div class="loginbox">
 <div class="loouter ">
  <div class="lomiddle">
   <div class="loinner col-md-5 col-sm-6 col-lg-4 col-center nopadding">
    <div class="lobox whitebg fulwidthm left pdg30 ">
     <div class="registerclose lgraytext"><i class="fa flaticon-cross97"></i> </div>
     <div class="loginrow fulwidthm left mgnB15 text-center josfinsanbold graytext fontsize20">Login With Your Account </div>
     <div class="loginrow fulwidthm left josfinsanbold graytext mgnB15">
      <label class="formlabel fontsize13 robotoregular graytext">Email </label> <span class=" required">*</span>
      <input type="email" id="username" class="cmnfrminput fulwidthm inputiconpdng" value="testaccount1@xyz.com"> <span class="loginicons"><i class="fa fa-user"></i></span>
      <div class="erorshow" id="unameerror"></div>
     </div>
     <div class="loginrow fulwidthm left josfinsanbold graytext mgnB15">
      <label class="formlabel fontsize13 robotoregular graytext">Password</label> <span class=" required">*</span>
      <input type="password" id="lpassword" class="cmnfrminput  fulwidthm inputiconpdng" value="123456"> <span class="loginicons"><i class="fa fa-lock"></i></span>
      <div class="erorshow" id="passerror"></div>
     </div>
     <div class=" text-right loginrow fulwidthm left robotoregular fontsize14 graytext mgnB15"> Forgot password? <a href="#" class=" lbluetext ">Click Here</a> </div>
     <div class="loginrow fulwidthm left josfinsanbold graytext mgnB15">
      <button class="btn lblue_bg whitetext fulwidthm font-size14 robotomedium" onclick="register()" style="margin-bottom: 37px;">Submit</button>
      <a href="#" class="btn lblue_bg whitetext fulwidthm font-size14 robotomedium" style="" >Signup with facebook</a>
      <a href="#" class="btn lblue_bg whitetext fulwidthm font-size14 robotomedium" >Signup with twitter</a>
      <p class="hr" ></p>
      <span class="orcls" >OR</span>
     </div>
     <div class="loginrow fulwidthm left font-size14 graytext mgnB15">Don't have an account? <a class="lbluetext signupclick">Sign Up</a> </div>
    </div>
   </div>
  </div>
 </div>
</div>