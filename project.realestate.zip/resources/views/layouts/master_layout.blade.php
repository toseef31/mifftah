@include('partials.header')
<div class="innerwraperful  pdgT15 fulwidthm left">
 <div class="resultwraperfull">
  @yield('content')   
 </div>
</div> 
@include('partials.footer')