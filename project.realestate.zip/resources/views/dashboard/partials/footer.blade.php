</div>
<!-- END APP CONTENT -->
</div><!-- app-container -->
<!-- END APP CONTAINER -->

<!-- START APP FOOTER -->
<div class="app-footer app-footer-default" id="footer">
  <div class="app-footer-line darken" style="background-color: #292f43;">
    <div class="copyright wide text-center">&copy; 2016 Dynamowebs. All right reserved in the Ukraine and other countries.</div>
  </div>
</div>
<!-- END APP FOOTER -->

<!-- APP OVERLAY -->
<div class="app-overlay"></div>
<!-- END APP OVERLAY -->
</div>
<!-- END APP WRAPPER -->
<!-- START SCRIPTS -->
<script type="text/javascript" src=" {{ asset('_admin/js/vendor/jquery/jquery.min.js') }} "></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/jquery/jquery-ui.min.js ')  }}"></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/bootstrap/bootstrap.min.js ')  }}"></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/moment/moment.min.js ')  }}"></script>

<script type="text/javascript" src=" {{  asset('_admin/js/vendor/customscrollbar/jquery.mCustomScrollbar.min.js ') }} "></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/bootstrap-select/bootstrap-select.js ')  }}"></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/bootstrap-datetimepicker/bootstrap-datetimepicker.js ') }} "></script>

<script type="text/javascript" src=" {{  asset('_admin/js/vendor/maskedinput/jquery.maskedinput.min.js ')  }}"></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/form-validator/jquery.form-validator.min.js ') }} "></script>

<script type="text/javascript" src="  {{ asset('_admin/js/vendor/noty/jquery.noty.packaged.js ') }} "></script>

<script type="text/javascript" src=" {{  asset('_admin/js/vendor/datatables/jquery.dataTables.min.js ') }} "></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/datatables/dataTables.bootstrap.min.js ') }} "></script>

<script type="text/javascript" src=" {{  asset('_admin/js/vendor/sweetalert/sweetalert.min.js ') }} "></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/knob/jquery.knob.min.js ') }} "></script>

<script type="text/javascript" src=" {{  asset('_admin/js/vendor/jvectormap/jquery-jvectormap.min.js ') }} "></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/jvectormap/jquery-jvectormap-world-mill-en.js ') }} "></script>
<script type="text/javascript" src=" {{  asset('_admin/js/vendor/jvectormap/jquery-jvectormap-us-aea-en.js ')}}  "></script>

<script type="text/javascript" src="  {{ asset('_admin/js/vendor/sparkline/jquery.sparkline.min.js ') }} "></script>

<script type="text/javascript" src=" {{  asset('_admin/js/vendor/morris/raphael.min.js ') }} "></script>
<script type="text/javascript" src="  {{ asset('_admin/js/vendor/morris/morris.min.js ') }} "></script>

<script type="text/javascript" src="  {{ asset('_admin/js/vendor/rickshaw/d3.v3.js ') }} "></script>
<script type="text/javascript" src="  {{ asset('_admin/js/vendor/rickshaw/rickshaw.min.js ') }} "></script>

<script type="text/javascript" src=" {{  asset('_admin/js/vendor/isotope/isotope.pkgd.min.js ')  }}"></script>

<script type="text/javascript" src=" {{  asset('_admin/js/app.js ') }} "></script>
<script type="text/javascript" src=" {{  asset('_admin/js/app_plugins.js ') }} "></script>
<script type="text/javascript" src=" {{  asset('_admin/js/app_demo.js ') }} "></script>
<!-- END SCRIPTS -->
<script type="text/javascript" src="  {{  asset('_admin/js/app_demo_dashboard.js ') }} "></script>

</body>
</html>